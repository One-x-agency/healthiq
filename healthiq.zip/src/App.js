import logo from './logo.svg';
import './App.css';
import Health from './health';
import Solutions from './solutions';
import Services from './services';
import Event from './event';

function App() {
  return (
    <div>
       {/* <Health/>  */}
       {/* <Solutions/>   */}
      {/* <Services/>  */}
      <Event/>
    </div>
  );
}

export default App;
