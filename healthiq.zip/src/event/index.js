import React from "react";
import "./event.css";
import Photo2 from "../assert/image/photo2.png";

export default function Event() {
  return (
    <div>
      <div className="mainback">
        <div className="container">
          <h1 className="mainh1">Events</h1>
          <p className="mainspan">Providing the best learning experience.</p>
        </div>
      </div>
      <div className="eventcontainer">
        <div>
          <h2 className="maineventh2">Upcoming Event</h2>
        </div>
        <div className="evemainfelxbox">
          <div className="eventfelx">
            <div>
              <h1 className="eventh1">
                Illinois Medical Oncology Society (IMOS)
              </h1>
              <div className="eveboder"></div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">Date & time</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p className="eventfirstp2">2025-04-11 08:00 AM EST</p>
              </div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">Location</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p>Le Méridien Chicago – Oakbrook Center!</p>
              </div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">About</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p>
                  The IMOS Spring Meeting focuses on AI-driven solutions{" "}
                  <br></br> to improve patient education, adherence, and
                  <br></br> outcomes in oncology practice management.
                </p>
              </div>
              <div className="eventsecflex1">
                <div className="eventflex2">
                  <p className="moreinfo">More details>>></p>
                </div>
                <div className="eventflex21">
                  <p className="eventflex3">Register Here</p>
                </div>
              </div>
            </div>
            <div>
              <img className="eventmainphoto" src={Photo2} alt="" />
            </div>
          </div>
        </div>
        <div className="evemainfelxbox">
          <div className="eventfelx">
            <div>
              <img className="eventmainphoto" src={Photo2} alt="" />
            </div>
            <div>
              <h1 className="eventh1">Imperial Palace Walk or Jog</h1>
              <div className="eveboder"></div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">Date & time</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p className="eventfirstp2">2025-04-04 10:00 AM JST</p>
              </div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">Location</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p>Japan</p>
              </div>
              <div className="eventsecflex">
                <div>
                  <p className="eventfirstp">About</p>
                </div>
                <p className="eventfirstp1">:</p>
                <p>
                  A very popular event for volunteers of all ages! <br></br> Choosing a
                  convenient time, participants walk or jog <br></br>around the Imperial
                  Palace for an hour or more,<br></br> individually or in groups, and get
                  a lovely souvenir <br></br>t-shirt while supporting kids in care!
                </p>
              </div>
              <div className="eventsecflex1">
                <div className="eventflex22">
                  <p className="moreinfo">More details>>></p>
                </div>
                <div className="eventflex22">
                  <p className="eventflex3">Register Here</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
